# Core AI

Oʻzbek tilida ishlaydigan chat yordamchi (Next.js 15 + React 19 + Tailwind 4 + Gemini).

## Ishga tushirish

```bash
bun install        # yoki: npm install
cp .env.example .env.local   # GEMINI_API_KEY ni kiriting
bun run dev        # http://localhost:3000
```

Boshqa buyruqlar: `bun run build`, `bun run lint`, `bun run typecheck`, `bun run test`.
AI Studio uchun eski `dist` papkali build kerak boʻlsa: `bun run build:aistudio`.

## Sozlamalar (`.env.local`)

| Oʻzgaruvchi | Vazifasi |
| --- | --- |
| `GEMINI_API_KEY` | Majburiy. Kalitsiz chat aniq xato xabarini koʻrsatadi. |
| `GEMINI_MODEL` | Ixtiyoriy, standart `gemini-2.5-flash`. |
| `NEXT_PUBLIC_USER_NAME` | Yon paneldagi profil nomi. |

## Tuzilma

- `app/api/chat/route.ts` — Gemini bilan oqimli (streaming) aloqa
- `lib/gemini.ts` — tarixni Gemini formatiga oʻtkazish (testlangan)
- `lib/conversation-store.ts` — suhbatlar xotirasi (localStorage, kvota himoyasi bilan)
- `hooks/use-chat.ts` — yuborish, toʻxtatish, qayta yaratish mantiqi
- `app/globals.css` — dizayn tokenlari (yorugʻ/qorongʻi mavzu)
- `components/*` — interfeys komponentlari
