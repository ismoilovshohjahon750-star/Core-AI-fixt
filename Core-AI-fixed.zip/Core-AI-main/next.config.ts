import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  output: 'standalone',
  reactStrictMode: true,
  poweredByHeader: false,
  webpack: (config, { dev }) => {
    // AI Studio muhitida HMR DISABLE_HMR orqali oʻchiriladi (fayl kuzatuvi miltillashga sabab boʻladi).
    if (dev && process.env.DISABLE_HMR === 'true') {
      config.watchOptions = { ignored: /.*/ };
    }
    return config;
  },
};

export default nextConfig;
