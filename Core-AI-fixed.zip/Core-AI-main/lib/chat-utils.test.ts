import test from 'node:test';
import assert from 'node:assert/strict';
import {
  removeEmojis,
  stripEmojis,
  categorizeDate,
  truncateSnippet,
  deriveTitle,
  filterConversations,
  groupConversations,
  formatFileSize,
  getAllMediaFromConversations,
  markdownToSpeech,
} from './chat-utils.ts';
import type { Conversation } from './types.ts';

const conv = (id: string, updatedAt: number, extra: Partial<Conversation> = {}): Conversation => ({
  id,
  title: `T${id}`,
  snippet: `S${id}`,
  updatedAt,
  messages: [],
  ...extra,
});

test('removeEmojis emoji larni olib tashlaydi, oddiy matn va belgilarni saqlaydi', () => {
  assert.equal(removeEmojis('Salom 🤖 dunyo 🚀! Bu ajoyib test 👍.'), 'Salom  dunyo ! Bu ajoyib test .');
  assert.equal(removeEmojis('Oddiy matn © 2026 ™ → ✓'), 'Oddiy matn © 2026 ™ → ✓');
  assert.equal(removeEmojis('Oʻzbekiston gʻururi'), 'Oʻzbekiston gʻururi');
});

test('stripEmojis oqim boʻlaklaridagi probellarni buzmaydi', () => {
  assert.equal(stripEmojis('salom '), 'salom ');
  assert.equal(stripEmojis(' dunyo'), ' dunyo');
  assert.equal(stripEmojis('bayroq 🇺🇿 va oila 👨‍👩‍👧'), 'bayroq  va oila ');
});

test('formatFileSize', () => {
  assert.equal(formatFileSize(512), '512 B');
  assert.equal(formatFileSize(2048), '2.0 KB');
  assert.equal(formatFileSize(1048576 * 2.5), '2.5 MB');
});

test('categorizeDate: BUGUN, KECHA, OLDINGI', () => {
  const now = new Date(2026, 10, 3, 12, 0, 0).getTime();
  assert.equal(categorizeDate(new Date(2026, 10, 3, 9, 30).getTime(), now), 'BUGUN');
  assert.equal(categorizeDate(new Date(2026, 10, 2, 18, 0).getTime(), now), 'KECHA');
  assert.equal(categorizeDate(new Date(2026, 9, 29, 10, 0).getTime(), now), 'OLDINGI');
});

test('categorizeDate oy chegarasida ham toʻgʻri ishlaydi', () => {
  const now = new Date(2026, 10, 1, 8, 0, 0).getTime();
  assert.equal(categorizeDate(new Date(2026, 9, 31, 23, 0).getTime(), now), 'KECHA');
});

test('truncateSnippet', () => {
  const truncated = truncateSnippet('Bu juda uzun xabar bolib, snippet formatida qisqartirilishi kerak', 25);
  assert.ok(truncated.endsWith('...'));
  assert.equal(truncated.length, 28);
  assert.equal(truncateSnippet('Qisqa', 25), 'Qisqa');
});

test('deriveTitle soʻz chegarasida qirqadi', () => {
  assert.equal(deriveTitle('   '), 'Yangi suhbat');
  assert.equal(deriveTitle('Salom'), 'Salom');
  const t = deriveTitle('Python dasturlash tilida maʼlumotlar tuzilmalari haqida tushuntiring', 'Yangi suhbat', 30);
  assert.ok(t.endsWith('…'));
  assert.ok(!t.includes('tuzilmal') || t.endsWith('tuzilmalari…'));
  assert.ok(t.length <= 31);
});

test('filterConversations sarlavha, snippet va xabarlar boʻyicha qidiradi', () => {
  const list = [
    conv('1', 1, { title: 'Python kodlash', snippet: 'Funksiya', messages: [{ id: 'm', role: 'user', content: 'Funksiya haqida', timestamp: 1 }] }),
    conv('2', 1, { title: 'React', snippet: 'hook', messages: [{ id: 'm', role: 'user', content: 'Hooklar', timestamp: 1 }] }),
  ];
  assert.equal(filterConversations(list, 'python').length, 1);
  assert.equal(filterConversations(list, 'hooklar')[0].title, 'React');
  assert.equal(filterConversations(list, '').length, 2);
});

test('groupConversations updatedAt boʻyicha toifalaydi va yangisini birinchi qoʻyadi', () => {
  const now = new Date(2026, 10, 3, 12).getTime();
  const grouped = groupConversations(
    [
      conv('a', new Date(2026, 10, 3, 8).getTime()),
      conv('b', new Date(2026, 10, 3, 11).getTime()),
      conv('c', new Date(2026, 10, 2, 8).getTime()),
      conv('d', new Date(2026, 8, 1).getTime()),
    ],
    now
  );
  assert.deepEqual(grouped.BUGUN.map((c) => c.id), ['b', 'a']);
  assert.equal(grouped.KECHA.length, 1);
  assert.equal(grouped.OLDINGI.length, 1);
});

test('getAllMediaFromConversations barcha suhbatlardagi fayllarni yigʻadi', () => {
  const media = getAllMediaFromConversations([
    conv('c1', 100, {
      title: 'Chat 1',
      messages: [
        {
          id: 'm1',
          role: 'user',
          content: 'rasm',
          timestamp: 200,
          attachments: [{ id: 'a1', name: 'photo.png', type: 'image/png', size: 1024, dataUrl: 'data:image/png;base64,AAAA' }],
        },
      ],
    }),
  ]);
  assert.equal(media.length, 1);
  assert.equal(media[0].attachment.name, 'photo.png');
  assert.equal(media[0].conversationTitle, 'Chat 1');
});

test('markdownToSpeech kod va belgilarni olib tashlaydi', () => {
  const out = markdownToSpeech('## Sarlavha\n**Qalin** matn va `kod`\n```js\nconst a = 1;\n```\n- element');
  assert.equal(out, 'Sarlavha Qalin matn va kod element');
});
