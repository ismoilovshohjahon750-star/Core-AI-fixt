import test from 'node:test';
import assert from 'node:assert/strict';
import { toGeminiContents, parseDataUrl, describeGeminiError } from './gemini.ts';

test('parseDataUrl base64 data URL ni ajratadi', () => {
  assert.deepEqual(parseDataUrl('data:image/png;base64,QUJD'), { mimeType: 'image/png', data: 'QUJD' });
  assert.equal(parseDataUrl('https://example.com/a.png'), null);
  assert.equal(parseDataUrl('data:text/plain,hello'), null);
});

test('toGeminiContents navbatma-navbat va user bilan boshlanib user bilan tugaydi', () => {
  const out = toGeminiContents([
    { role: 'assistant', content: 'Eski javob' },
    { role: 'user', content: 'Savol 1' },
    { role: 'user', content: 'Savol 2' },
    { role: 'assistant', content: 'Javob' },
    { role: 'user', content: 'Savol 3' },
  ]);
  assert.deepEqual(out.map((c) => c.role), ['user', 'model', 'user']);
  assert.equal(out[0].parts?.length, 2);
});

test('toGeminiContents xato xabarlarni tashlab yuboradi', () => {
  const out = toGeminiContents([
    { role: 'user', content: 'Salom' },
    { role: 'assistant', content: 'Xatolik yuz berdi', error: true },
    { role: 'user', content: 'Qayta' },
  ]);
  assert.deepEqual(out.map((c) => c.role), ['user']);
  assert.equal(out[0].parts?.length, 2);
});

test('toGeminiContents faqat fayl yuborilganda standart savol qoʻshadi va rasmni inlineData qiladi', () => {
  const out = toGeminiContents([
    {
      role: 'user',
      content: '',
      attachments: [{ name: 'a.png', type: 'image/png', dataUrl: 'data:image/png;base64,QUJD' }],
    },
  ]);
  const parts = out[0].parts ?? [];
  assert.equal(parts.length, 2);
  assert.equal(parts[0].inlineData?.data, 'QUJD');
  assert.ok(typeof parts[1].text === 'string' && parts[1].text.length > 0);
});

test('toGeminiContents qoʻllab-quvvatlanmaydigan MIME ni yubormaydi', () => {
  const out = toGeminiContents([
    {
      role: 'user',
      content: 'Mana',
      attachments: [{ name: 'x.gif', type: 'image/gif', dataUrl: 'data:image/gif;base64,QUJD' }],
    },
  ]);
  assert.equal(out[0].parts?.length, 1);
});

test('toGeminiContents eski xabarlardagi fayllarni faqat nomi bilan eslatadi', () => {
  const att = { name: 'old.png', type: 'image/png', dataUrl: 'data:image/png;base64,QUJD' };
  const out = toGeminiContents([
    { role: 'user', content: 'bir', attachments: [att] },
    { role: 'assistant', content: 'a' },
    { role: 'user', content: 'ikki' },
    { role: 'assistant', content: 'b' },
    { role: 'user', content: 'uch' },
  ]);
  const firstParts = out[0].parts ?? [];
  assert.ok(firstParts.every((p) => !p.inlineData));
  assert.ok(firstParts.some((p) => p.text?.includes('old.png')));
});

test('describeGeminiError holat kodlarini tushunarli xabarga aylantiradi', () => {
  assert.equal(describeGeminiError({ status: 429 }).status, 429);
  assert.equal(describeGeminiError({ status: 403 }).status, 502);
  assert.equal(describeGeminiError(new Error('x')).status, 502);
});
