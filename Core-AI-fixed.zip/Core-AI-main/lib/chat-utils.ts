import type { ChatAttachment, Conversation, ConversationCategory, MediaItem } from './types.ts';

/**
 * Emoji belgilarini olib tashlaydi (probel va chekkalarni TEGMAYDI).
 * Oqimli (streaming) javoblarning boʻlaklari uchun xavfsiz: "salom " -> "salom ".
 */
const EMOJI_PATTERN =
  /(?:\p{Extended_Pictographic}\uFE0F|\p{Emoji_Presentation}|\p{Emoji_Modifier}|[\u{1F1E6}-\u{1F1FF}]|\u20E3|\uFE0F|\u200D)/gu;

export function stripEmojis(text: string): string {
  if (!text) return '';
  return text.replace(EMOJI_PATTERN, '');
}

/** Emoji larni olib tashlaydi va chekkadagi boʻsh joylarni kesadi. */
export function removeEmojis(text: string): string {
  return stripEmojis(text).trim();
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export const CATEGORY_LABELS: Record<ConversationCategory, string> = {
  BUGUN: 'Bugun',
  KECHA: 'Kecha',
  OLDINGI: 'Avvalroq',
};

export const CATEGORY_ORDER: ConversationCategory[] = ['BUGUN', 'KECHA', 'OLDINGI'];

/** Vaqt tamgʻasini 'BUGUN' / 'KECHA' / 'OLDINGI' toifasiga ajratadi. */
export function categorizeDate(timestamp: number, currentTimestamp = Date.now()): ConversationCategory {
  const current = new Date(currentTimestamp);
  const startOfToday = new Date(current.getFullYear(), current.getMonth(), current.getDate()).getTime();
  const startOfYesterday = new Date(current.getFullYear(), current.getMonth(), current.getDate() - 1).getTime();

  if (timestamp >= startOfToday) return 'BUGUN';
  if (timestamp >= startOfYesterday) return 'KECHA';
  return 'OLDINGI';
}

export function truncateSnippet(text: string, maxLength = 36): string {
  const cleaned = removeEmojis(text).replace(/\s+/g, ' ').trim();
  if (cleaned.length <= maxLength) return cleaned;
  return cleaned.substring(0, maxLength) + '...';
}

/** Suhbat sarlavhasini birinchi xabardan, soʻz chegarasida qirqib hosil qiladi. */
export function deriveTitle(text: string, fallback = 'Yangi suhbat', maxLength = 40): string {
  const cleaned = removeEmojis(text).replace(/\s+/g, ' ').trim();
  if (!cleaned) return fallback;
  if (cleaned.length <= maxLength) return cleaned;
  const cut = cleaned.slice(0, maxLength);
  const lastSpace = cut.lastIndexOf(' ');
  const base = lastSpace > maxLength * 0.5 ? cut.slice(0, lastSpace) : cut;
  return base.replace(/[\s,.;:!?-]+$/, '') + '…';
}

export function filterConversations(conversations: Conversation[], query: string): Conversation[] {
  const trimmed = query.trim().toLowerCase();
  if (!trimmed) return conversations;

  return conversations.filter((conv) => {
    if (conv.title.toLowerCase().includes(trimmed)) return true;
    if (conv.snippet.toLowerCase().includes(trimmed)) return true;
    return conv.messages.some((m) => m.content.toLowerCase().includes(trimmed));
  });
}

/** Suhbatlarni `updatedAt` boʻyicha toifalaydi (saqlangan toifa eskirib qolmasligi uchun har safar hisoblanadi). */
export function groupConversations(
  conversations: Conversation[],
  now = Date.now()
): Record<ConversationCategory, Conversation[]> {
  const grouped: Record<ConversationCategory, Conversation[]> = { BUGUN: [], KECHA: [], OLDINGI: [] };
  const sorted = [...conversations].sort((a, b) => b.updatedAt - a.updatedAt);
  for (const conv of sorted) {
    grouped[categorizeDate(conv.updatedAt, now)].push(conv);
  }
  return grouped;
}

export function isImageAttachment(att: Pick<ChatAttachment, 'type'>): boolean {
  return att.type.startsWith('image/');
}

export function isCodeFileName(name: string): boolean {
  return /\.(js|jsx|ts|tsx|py|json|html|css|sql|xml|sh|java|c|cpp|go|rs|php|rb|yml|yaml)$/i.test(name);
}

export function getAllMediaFromConversations(conversations: Conversation[]): MediaItem[] {
  const items: MediaItem[] = [];
  for (const conv of conversations) {
    for (const msg of conv.messages) {
      if (!msg.attachments?.length) continue;
      for (const att of msg.attachments) {
        items.push({
          id: `${conv.id}-${msg.id}-${att.id}`,
          attachment: att,
          conversationId: conv.id,
          conversationTitle: conv.title || 'Core AI',
          timestamp: msg.timestamp || conv.updatedAt || Date.now(),
          role: msg.role,
        });
      }
    }
  }
  return items.sort((a, b) => b.timestamp - a.timestamp);
}

/** Markdown matnni ovoz chiqarib oʻqish uchun tozalaydi (kod bloklari va belgilar oʻqilmaydi). */
export function markdownToSpeech(markdown: string): string {
  return markdown
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/`([^`]*)`/g, '$1')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/^\s*[-*+]\s+/gm, '')
    .replace(/^\s*\d+\.\s+/gm, '')
    .replace(/[*_~>|]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}
