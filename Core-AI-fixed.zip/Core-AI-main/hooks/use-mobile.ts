import { useSyncExternalStore } from 'react';

const DEFAULT_BREAKPOINT = 1024;

/** Ekran kengligi `breakpoint` dan kichik boʻlsa true. Server tomonida false qaytaradi. */
export function useIsMobile(breakpoint = DEFAULT_BREAKPOINT) {
  return useSyncExternalStore(
    (callback) => {
      const mql = window.matchMedia(`(max-width: ${breakpoint - 1}px)`);
      mql.addEventListener('change', callback);
      return () => mql.removeEventListener('change', callback);
    },
    () => window.matchMedia(`(max-width: ${breakpoint - 1}px)`).matches,
    () => false
  );
}
