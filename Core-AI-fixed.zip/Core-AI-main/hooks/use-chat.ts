'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useConversations, flushConversations } from '@/lib/conversation-store';
import { deriveTitle, stripEmojis, removeEmojis, truncateSnippet } from '@/lib/chat-utils';
import type { ChatAttachment, ChatMessageItem, Conversation } from '@/lib/types';

/** undefined — avtomatik (eng yangi suhbat), null — yangi (hali saqlanmagan) suhbat, string — tanlangan suhbat. */
type Selection = string | null | undefined;

const ERROR_FALLBACK = 'Javob olishda xatolik yuz berdi. Qayta urinib koʻring.';
const NETWORK_ERROR = 'Aloqa oʻrnatib boʻlmadi. Internet ulanishini tekshirib, qayta urinib koʻring.';

let idCounter = 0;
const uid = (prefix: string) => `${prefix}-${Date.now().toString(36)}-${(idCounter++).toString(36)}`;

export function useChat() {
  const { conversations, hydrated, update, clearAll } = useConversations();
  const [selection, setSelection] = useState<Selection>(undefined);
  const [busyId, setBusyId] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const conversationsRef = useRef(conversations);

  useEffect(() => {
    conversationsRef.current = conversations;
  }, [conversations]);

  const activeId = useMemo(() => {
    if (selection === null) return null;
    if (typeof selection === 'string' && conversations.some((c) => c.id === selection)) return selection;
    const latest = [...conversations].sort((a, b) => b.updatedAt - a.updatedAt)[0];
    return latest?.id ?? null;
  }, [selection, conversations]);

  const active: Conversation | null = useMemo(
    () => conversations.find((c) => c.id === activeId) ?? null,
    [conversations, activeId]
  );

  const patchConversation = useCallback(
    (id: string, fn: (c: Conversation) => Conversation) => {
      update((prev) => prev.map((c) => (c.id === id ? fn(c) : c)));
    },
    [update]
  );

  const patchMessage = useCallback(
    (convId: string, msgId: string, fn: (m: ChatMessageItem) => ChatMessageItem) => {
      patchConversation(convId, (c) => ({ ...c, messages: c.messages.map((m) => (m.id === msgId ? fn(m) : m)) }));
    },
    [patchConversation]
  );

  /** Serverga soʻrov yuboradi va javobni oqim bilan `assistantId` xabariga yozib boradi. */
  const runCompletion = useCallback(
    async (convId: string, history: ChatMessageItem[], assistantId: string) => {
      const controller = new AbortController();
      abortRef.current = controller;
      setBusyId(convId);

      let received = '';
      let failure: string | null = null;

      try {
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ messages: history }),
          signal: controller.signal,
        });

        if (!res.ok || !res.body) {
          let message = ERROR_FALLBACK;
          try {
            const data = (await res.json()) as { error?: string };
            if (data.error) message = data.error;
          } catch {
            // JSON emas — standart xabar
          }
          failure = message;
        } else {
          const reader = res.body.getReader();
          const decoder = new TextDecoder();
          let frame = 0;
          const flush = () => {
            frame = 0;
            patchMessage(convId, assistantId, (m) => ({ ...m, content: received }));
          };
          try {
            for (;;) {
              const { done, value } = await reader.read();
              if (done) break;
              received += decoder.decode(value, { stream: true });
              if (!frame) frame = requestAnimationFrame(flush);
            }
            received += decoder.decode();
          } finally {
            if (frame) cancelAnimationFrame(frame);
          }
        }
      } catch (error) {
        if ((error as { name?: string }).name !== 'AbortError') {
          failure = received ? null : NETWORK_ERROR;
          if (received) received += '\n\n_(Aloqa uzildi, javob toʻliq emas.)_';
        }
      } finally {
        if (abortRef.current === controller) abortRef.current = null;
      }

      const finalText = stripEmojis(received).trim();
      const aborted = controller.signal.aborted;

      if (failure) {
        patchMessage(convId, assistantId, (m) => ({ ...m, content: failure!, error: true }));
      } else if (!finalText && aborted) {
        // Foydalanuvchi hech narsa kelmasdan toʻxtatdi — boʻsh xabarni olib tashlaymiz.
        patchConversation(convId, (c) => ({ ...c, messages: c.messages.filter((m) => m.id !== assistantId) }));
      } else {
        patchConversation(convId, (c) => ({
          ...c,
          updatedAt: Date.now(),
          messages: c.messages.map((m) => (m.id === assistantId ? { ...m, content: finalText } : m)),
        }));
      }

      setBusyId((current) => (current === convId ? null : current));
      flushConversations();
    },
    [patchConversation, patchMessage]
  );

  const sendMessage = useCallback(
    async (rawText: string, attachments: ChatAttachment[] = []) => {
      if (busyId) return;
      const text = removeEmojis(rawText);
      if (!text && attachments.length === 0) return;

      const now = Date.now();
      const userMessage: ChatMessageItem = {
        id: uid('usr'),
        role: 'user',
        content: text,
        timestamp: now,
        attachments: attachments.length > 0 ? attachments : undefined,
      };
      const assistantMessage: ChatMessageItem = { id: uid('ai'), role: 'assistant', content: '', timestamp: now };

      const snippet = text
        ? truncateSnippet(text, 48)
        : `${attachments[0].name}${attachments.length > 1 ? ` va yana ${attachments.length - 1} ta fayl` : ''}`;

      let convId = activeId;
      let history: ChatMessageItem[];

      if (!convId || !active) {
        convId = uid('conv');
        history = [userMessage];
        const created: Conversation = {
          id: convId,
          title: deriveTitle(text || attachments[0].name),
          snippet,
          updatedAt: now,
          messages: [userMessage, assistantMessage],
        };
        update((prev) => [created, ...prev]);
      } else {
        history = [...active.messages, userMessage];
        const id = convId;
        patchConversation(id, (c) => ({
          ...c,
          snippet,
          updatedAt: now,
          messages: [...c.messages, userMessage, assistantMessage],
        }));
      }

      setSelection(convId);
      await runCompletion(convId, history, assistantMessage.id);
    },
    [active, activeId, busyId, patchConversation, runCompletion, update]
  );

  /** Oxirgi javobni qayta yaratadi (xato xabari boʻlsa — uni almashtiradi). */
  const regenerate = useCallback(async () => {
    if (busyId || !active) return;
    const messages = active.messages;
    const lastUserIndex = messages.map((m) => m.role).lastIndexOf('user');
    if (lastUserIndex < 0) return;

    const history = messages.slice(0, lastUserIndex + 1);
    const assistantMessage: ChatMessageItem = { id: uid('ai'), role: 'assistant', content: '', timestamp: Date.now() };
    const convId = active.id;

    patchConversation(convId, (c) => ({ ...c, messages: [...history, assistantMessage] }));
    await runCompletion(convId, history, assistantMessage.id);
  }, [active, busyId, patchConversation, runCompletion]);

  const stop = useCallback(() => {
    abortRef.current?.abort();
  }, []);

  const startNewChat = useCallback(() => {
    setSelection(null);
  }, []);

  const selectConversation = useCallback((id: string) => {
    setSelection(id);
  }, []);

  const deleteConversation = useCallback(
    (id: string) => {
      if (busyId === id) abortRef.current?.abort();
      update((prev) => prev.filter((c) => c.id !== id));
      if (activeId === id) setSelection(undefined);
    },
    [activeId, busyId, update]
  );

  const renameConversation = useCallback(
    (id: string, title: string) => {
      const clean = removeEmojis(title).slice(0, 80);
      if (!clean) return;
      patchConversation(id, (c) => ({ ...c, title: clean }));
    },
    [patchConversation]
  );

  const clearActiveConversation = useCallback(() => {
    if (!activeId) return;
    if (busyId === activeId) abortRef.current?.abort();
    // Boʻsh suhbat saqlanmaydi — butunlay olib tashlaymiz va yangi suhbat holatiga qaytamiz.
    update((prev) => prev.filter((c) => c.id !== activeId));
    setSelection(null);
  }, [activeId, busyId, update]);

  const clearEverything = useCallback(() => {
    abortRef.current?.abort();
    clearAll();
    setSelection(null);
  }, [clearAll]);

  const setReaction = useCallback(
    (msgId: string, reaction: 'liked' | 'disliked', value: boolean) => {
      if (!activeId) return;
      patchMessage(activeId, msgId, (m) => ({
        ...m,
        liked: reaction === 'liked' ? value : false,
        disliked: reaction === 'disliked' ? value : false,
      }));
    },
    [activeId, patchMessage]
  );

  // Sahifa yopilganda ochiq soʻrovni toʻxtatamiz.
  useEffect(() => () => abortRef.current?.abort(), []);

  return {
    conversations,
    hydrated,
    active,
    activeId,
    busyId,
    isBusyHere: busyId !== null && busyId === activeId,
    isBusyElsewhere: busyId !== null && busyId !== activeId,
    sendMessage,
    regenerate,
    stop,
    startNewChat,
    selectConversation,
    deleteConversation,
    renameConversation,
    clearActiveConversation,
    clearEverything,
    setReaction,
  };
}
