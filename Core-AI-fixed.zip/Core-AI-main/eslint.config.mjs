import { defineConfig, globalIgnores } from 'eslint/config';
import next from 'eslint-config-next';

export default defineConfig([
  ...next,
  globalIgnores(['.next/**', 'dist/**', 'node_modules/**', 'next-env.d.ts']),
]);
