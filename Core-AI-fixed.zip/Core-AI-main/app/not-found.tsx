import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="flex h-dvh flex-col items-center justify-center gap-5 bg-canvas px-6 text-center text-fg">
      <p className="text-7xl font-semibold tracking-tight text-accent">404</p>
      <div className="space-y-2">
        <h1 className="text-xl font-semibold">Sahifa topilmadi</h1>
        <p className="max-w-sm text-sm leading-relaxed text-muted">
          Qidirayotgan sahifangiz mavjud emas yoki boshqa manzilga koʻchirilgan.
        </p>
      </div>
      <Link
        href="/"
        className="rounded-xl bg-accent px-5 py-2.5 text-sm font-semibold text-accent-fg transition hover:bg-accent-strong"
      >
        Bosh sahifaga qaytish
      </Link>
    </main>
  );
}
