import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';
import { stripEmojis } from '@/lib/chat-utils';
import {
  buildSystemInstruction,
  describeGeminiError,
  toGeminiContents,
  type IncomingMessage,
} from '@/lib/gemini';

export const runtime = 'nodejs';
export const maxDuration = 60;

const MAX_BODY_BYTES = 40 * 1024 * 1024;
const DEFAULT_MODEL = 'gemini-2.5-flash';

function jsonError(message: string, status: number) {
  return NextResponse.json({ error: message }, { status, headers: { 'Cache-Control': 'no-store' } });
}

export async function POST(req: NextRequest) {
  const declaredLength = Number(req.headers.get('content-length') ?? 0);
  if (declaredLength > MAX_BODY_BYTES) {
    return jsonError('Yuborilgan maʼlumot hajmi juda katta. Fayllarni kamaytiring.', 413);
  }

  let body: { messages?: IncomingMessage[] };
  try {
    body = await req.json();
  } catch {
    return jsonError("So'rov formati noto'g'ri.", 400);
  }

  if (!Array.isArray(body.messages) || body.messages.length === 0) {
    return jsonError('Savol matni yoki biriktirilgan fayl kiritilmadi.', 400);
  }

  const contents = toGeminiContents(body.messages);
  if (contents.length === 0) {
    return jsonError('Savol matni yoki biriktirilgan fayl kiritilmadi.', 400);
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return jsonError(
      'GEMINI_API_KEY sozlanmagan. Loyiha papkasida .env.local faylini yarating, unga GEMINI_API_KEY=... qatorini qoʻshing va serverni qayta ishga tushiring.',
      503
    );
  }

  const ai = new GoogleGenAI({ apiKey });
  const model = process.env.GEMINI_MODEL?.trim() || DEFAULT_MODEL;

  try {
    const stream = await ai.models.generateContentStream({
      model,
      contents,
      config: {
        systemInstruction: buildSystemInstruction(),
        temperature: 0.6,
        abortSignal: req.signal,
      },
    });

    const encoder = new TextEncoder();
    const iterator = stream[Symbol.asyncIterator]();

    // Birinchi boʻlakni oldindan kutamiz: xato boʻlsa, toʻgʻri HTTP status qaytara olamiz.
    let first: IteratorResult<{ text?: string }>;
    try {
      first = await iterator.next();
    } catch (error) {
      console.error('[chat] Gemini xatosi:', error);
      const { status, message } = describeGeminiError(error);
      return jsonError(message, status);
    }

    const readable = new ReadableStream<Uint8Array>({
      async start(controller) {
        try {
          let current = first;
          let produced = false;
          while (!current.done) {
            const text = stripEmojis(current.value.text ?? '');
            if (text) {
              produced = true;
              controller.enqueue(encoder.encode(text));
            }
            current = await iterator.next();
          }
          if (!produced) {
            controller.enqueue(encoder.encode('Model boʻsh javob qaytardi. Savolni boshqacha ifodalab qayta urinib koʻring.'));
          }
          controller.close();
        } catch (error) {
          if (req.signal.aborted) {
            controller.close();
          } else {
            console.error('[chat] Oqim xatosi:', error);
            controller.error(error);
          }
        }
      },
      cancel() {
        void iterator.return?.();
      },
    });

    return new Response(readable, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-store, no-transform',
        'X-Accel-Buffering': 'no',
      },
    });
  } catch (error) {
    console.error('[chat] Gemini xatosi:', error);
    const { status, message } = describeGeminiError(error);
    return jsonError(message, status);
  }
}
