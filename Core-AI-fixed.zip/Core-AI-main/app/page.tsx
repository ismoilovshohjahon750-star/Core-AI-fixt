'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowDown, Menu, Settings, SquarePen, Trash2 } from 'lucide-react';
import type { ChatAttachment } from '@/lib/types';
import { useChat } from '@/hooks/use-chat';
import { useIsMobile } from '@/hooks/use-mobile';
import { useTheme } from '@/lib/theme';
import { Sidebar } from '@/components/Sidebar';
import { ChatMessage } from '@/components/ChatMessage';
import { ChatInput, type ChatInputHandle } from '@/components/ChatInput';
import { SettingsModal } from '@/components/SettingsModal';
import { ConfirmDialog, type ConfirmRequest } from '@/components/ConfirmDialog';
import { ImageLightbox } from '@/components/ImageLightbox';
import { Welcome } from '@/components/Welcome';
import { cn } from '@/lib/utils';

const STICK_THRESHOLD_PX = 120;

function HeaderButton({
  label,
  onClick,
  danger,
  children,
}: {
  label: string;
  onClick: () => void;
  danger?: boolean;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={label}
      aria-label={label}
      className={cn(
        'cursor-pointer rounded-xl p-2.5 text-muted transition hover:bg-hover',
        danger ? 'hover:text-danger' : 'hover:text-fg'
      )}
    >
      {children}
    </button>
  );
}

export default function Home() {
  const chat = useChat();
  const { active, hydrated } = chat;
  const { preference, setPreference } = useTheme();
  const isMobile = useIsMobile(1024);

  const [mobileOpen, setMobileOpen] = useState(false);
  const [desktopOpen, setDesktopOpen] = useState(true);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [confirm, setConfirm] = useState<ConfirmRequest | null>(null);
  const [preview, setPreview] = useState<ChatAttachment | null>(null);
  const [showJump, setShowJump] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const stickRef = useRef(true);
  const composerRef = useRef<ChatInputHandle>(null);

  const messages = active?.messages;
  const lastMessage = messages?.[messages.length - 1];
  const hasMessages = !!messages && messages.length > 0;

  const scrollToBottom = useCallback((smooth = false) => {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
  }, []);

  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const distance = el.scrollHeight - el.scrollTop - el.clientHeight;
    stickRef.current = distance < STICK_THRESHOLD_PX;
    setShowJump(distance > 400);
  };

  // Javob oqib kelayotganda faqat foydalanuvchi pastda boʻlsa avtomatik pastga tushamiz.
  useEffect(() => {
    if (stickRef.current) scrollToBottom();
  }, [lastMessage?.content, messages?.length, scrollToBottom]);

  // Suhbat almashganda har doim pastga.
  useEffect(() => {
    stickRef.current = true;
    scrollToBottom();
  }, [chat.activeId, scrollToBottom]);

  const toggleSidebar = () => {
    if (isMobile) setMobileOpen((v) => !v);
    else setDesktopOpen((v) => !v);
  };

  const closeSidebarOnMobile = () => setMobileOpen(false);

  const handleSend = (text: string, attachments: ChatAttachment[]) => {
    stickRef.current = true;
    void chat.sendMessage(text, attachments);
  };

  const requestDelete = (id: string) => {
    const conv = chat.conversations.find((c) => c.id === id);
    setConfirm({
      title: 'Suhbatni oʻchirish',
      description: `"${conv?.title ?? 'Suhbat'}" butunlay oʻchiriladi. Bu amalni ortga qaytarib boʻlmaydi.`,
      confirmLabel: 'Oʻchirish',
      onConfirm: () => chat.deleteConversation(id),
    });
  };

  const requestClearActive = () => {
    setConfirm({
      title: 'Suhbatni tozalash',
      description: 'Ushbu suhbatdagi barcha xabarlar oʻchiriladi. Bu amalni ortga qaytarib boʻlmaydi.',
      confirmLabel: 'Tozalash',
      onConfirm: chat.clearActiveConversation,
    });
  };

  const requestDeleteAll = () => {
    setSettingsOpen(false);
    setConfirm({
      title: 'Barcha suhbatlarni oʻchirish',
      description: `Jami ${chat.conversations.length} ta suhbat va ulardagi fayllar oʻchiriladi. Bu amalni ortga qaytarib boʻlmaydi.`,
      confirmLabel: 'Hammasini oʻchirish',
      onConfirm: chat.clearEverything,
    });
  };

  const newChat = () => {
    chat.startNewChat();
    closeSidebarOnMobile();
    requestAnimationFrame(() => composerRef.current?.focus());
  };

  const sidebarVisible = isMobile ? mobileOpen : desktopOpen;

  return (
    <div className="flex h-dvh w-full overflow-hidden bg-canvas text-fg">
      <Sidebar
        conversations={chat.conversations}
        activeId={chat.activeId}
        mobileOpen={mobileOpen}
        desktopOpen={desktopOpen}
        onClose={() => (isMobile ? setMobileOpen(false) : setDesktopOpen(false))}
        onSelect={(id) => {
          chat.selectConversation(id);
          closeSidebarOnMobile();
        }}
        onNewChat={newChat}
        onDelete={requestDelete}
        onRename={chat.renameConversation}
        onOpenSettings={() => {
          closeSidebarOnMobile();
          setSettingsOpen(true);
        }}
      />

      <main className="relative flex min-w-0 flex-1 flex-col">
        <header className="flex h-14 shrink-0 items-center justify-between gap-2 border-b border-line px-2 pt-[env(safe-area-inset-top)] sm:px-3">
          <div className="flex min-w-0 items-center gap-1">
            {(!sidebarVisible || isMobile) && (
              <HeaderButton label="Panelni ochish" onClick={toggleSidebar}>
                <Menu className="h-5 w-5" aria-hidden />
              </HeaderButton>
            )}
            <p className="min-w-0 truncate px-1.5 text-[15px] font-semibold">{active?.title ?? 'Yangi suhbat'}</p>
          </div>
          <div className="flex items-center">
            <HeaderButton label="Yangi suhbat" onClick={newChat}>
              <SquarePen className="h-[18px] w-[18px]" aria-hidden />
            </HeaderButton>
            {hasMessages && (
              <HeaderButton label="Suhbatni tozalash" onClick={requestClearActive} danger>
                <Trash2 className="h-[18px] w-[18px]" aria-hidden />
              </HeaderButton>
            )}
            <HeaderButton label="Sozlamalar" onClick={() => setSettingsOpen(true)}>
              <Settings className="h-[18px] w-[18px]" aria-hidden />
            </HeaderButton>
          </div>
        </header>

        <div ref={scrollRef} onScroll={handleScroll} className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 sm:px-6">
          {!hydrated ? null : !hasMessages ? (
            <Welcome onPick={(prompt) => composerRef.current?.setDraft(prompt)} />
          ) : (
            <div
              role="log"
              aria-label="Suhbat"
              aria-busy={chat.isBusyHere}
              className="mx-auto flex w-full max-w-3xl flex-col gap-7 py-8"
            >
              {messages!.map((message, index) => {
                const isLast = index === messages!.length - 1;
                return (
                  <ChatMessage
                    key={message.id}
                    message={message}
                    isLast={isLast}
                    isStreaming={chat.isBusyHere && isLast && message.role === 'assistant'}
                    onRegenerate={isLast && message.role === 'assistant' && !chat.busyId ? chat.regenerate : undefined}
                    onReact={chat.setReaction}
                    onPreviewImage={setPreview}
                  />
                );
              })}
            </div>
          )}
        </div>

        <div className="relative shrink-0 bg-canvas pt-2">
          {showJump && hasMessages && (
            <button
              type="button"
              onClick={() => scrollToBottom(true)}
              className="anim-pop absolute -top-12 left-1/2 flex h-9 w-9 -translate-x-1/2 cursor-pointer items-center justify-center rounded-full border border-line bg-raised text-muted shadow-float transition hover:text-fg"
              aria-label="Eng oxiriga tushish"
            >
              <ArrowDown className="h-4 w-4" aria-hidden />
            </button>
          )}
          <ChatInput
            ref={composerRef}
            onSend={handleSend}
            onStop={chat.stop}
            isGenerating={chat.isBusyHere}
            disabledReason={chat.isBusyElsewhere ? 'Boshqa suhbatda javob tayyorlanmoqda...' : undefined}
          />
        </div>
      </main>

      <SettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        preference={preference}
        onChangeTheme={setPreference}
        onDeleteAll={requestDeleteAll}
        hasConversations={chat.conversations.length > 0}
      />
      <ConfirmDialog request={confirm} onClose={() => setConfirm(null)} />
      <ImageLightbox attachment={preview} onClose={() => setPreview(null)} />
    </div>
  );
}
