'use client';

import { useCallback, useEffect, useImperativeHandle, useRef, useState, type Ref } from 'react';
import { ArrowUp, Loader2, Paperclip, Square } from 'lucide-react';
import type { ChatAttachment } from '@/lib/types';
import {
  FILE_ACCEPT,
  MAX_FILES,
  MAX_FILE_BYTES,
  MAX_TOTAL_BYTES,
  classifyFile,
  fileToAttachment,
} from '@/lib/file-utils';
import { formatFileSize } from '@/lib/chat-utils';
import { cn } from '@/lib/utils';
import { AttachmentChip } from './AttachmentChip';

export interface ChatInputHandle {
  focus: () => void;
  setDraft: (text: string) => void;
}

interface ChatInputProps {
  onSend: (text: string, attachments: ChatAttachment[]) => void;
  onStop: () => void;
  isGenerating: boolean;
  disabledReason?: string;
  ref?: Ref<ChatInputHandle>;
}

export function ChatInput({ onSend, onStop, isGenerating, disabledReason, ref }: ChatInputProps) {
  const [text, setText] = useState('');
  const [attachments, setAttachments] = useState<ChatAttachment[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const [isReading, setIsReading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const dragDepth = useRef(0);
  const noticeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useImperativeHandle(ref, () => ({
    focus: () => textareaRef.current?.focus(),
    setDraft: (value: string) => {
      setText(value);
      requestAnimationFrame(() => {
        const el = textareaRef.current;
        if (!el) return;
        el.focus();
        el.setSelectionRange(value.length, value.length);
      });
    },
  }));

  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
  }, [text]);

  useEffect(() => () => {
    if (noticeTimer.current) clearTimeout(noticeTimer.current);
  }, []);

  const showNotice = useCallback((message: string) => {
    setNotice(message);
    if (noticeTimer.current) clearTimeout(noticeTimer.current);
    noticeTimer.current = setTimeout(() => setNotice(null), 6000);
  }, []);

  const addFiles = useCallback(
    async (files: File[]) => {
      if (files.length === 0) return;
      setIsReading(true);
      const problems: string[] = [];
      const added: ChatAttachment[] = [];
      let total = attachments.reduce((sum, a) => sum + a.size, 0);
      let count = attachments.length;

      for (const file of files) {
        const kind = classifyFile(file);
        if (kind === 'unsupported') {
          problems.push(`"${file.name}" formati qoʻllab-quvvatlanmaydi (rasm: PNG, JPG, WEBP; hujjat: PDF; matn va kod fayllari)`);
          continue;
        }
        if (count >= MAX_FILES) {
          problems.push(`Bir vaqtda eng koʻpi bilan ${MAX_FILES} ta fayl biriktiriladi`);
          break;
        }
        if (file.size > MAX_FILE_BYTES) {
          problems.push(`"${file.name}" juda katta (${formatFileSize(file.size)}; chegara ${formatFileSize(MAX_FILE_BYTES)})`);
          continue;
        }
        if (total + file.size > MAX_TOTAL_BYTES) {
          problems.push(`Fayllarning umumiy hajmi ${formatFileSize(MAX_TOTAL_BYTES)} dan oshmasligi kerak`);
          continue;
        }
        try {
          added.push(await fileToAttachment(file, kind));
          total += file.size;
          count += 1;
        } catch {
          problems.push(`"${file.name}" faylini oʻqib boʻlmadi`);
        }
      }

      if (added.length > 0) setAttachments((prev) => [...prev, ...added]);
      if (problems.length > 0) showNotice(problems[0] + (problems.length > 1 ? ` (+${problems.length - 1} ta muammo)` : ''));
      setIsReading(false);
    },
    [attachments, showNotice]
  );

  const canSend = (text.trim().length > 0 || attachments.length > 0) && !isGenerating && !isReading && !disabledReason;

  const submit = () => {
    if (!canSend) return;
    onSend(text.trim(), attachments);
    setText('');
    setAttachments([]);
    setNotice(null);
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      submit();
    }
  };

  const onPaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const files = Array.from(e.clipboardData.files);
    if (files.length > 0) {
      if (!e.clipboardData.getData('text')) e.preventDefault();
      void addFiles(files);
    }
  };

  const hasFiles = (e: React.DragEvent) => Array.from(e.dataTransfer.types).includes('Files');

  const onDragEnter = (e: React.DragEvent) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    dragDepth.current += 1;
    setIsDragging(true);
  };
  const onDragLeave = (e: React.DragEvent) => {
    if (!hasFiles(e)) return;
    dragDepth.current = Math.max(0, dragDepth.current - 1);
    if (dragDepth.current === 0) setIsDragging(false);
  };
  const onDrop = (e: React.DragEvent) => {
    if (!hasFiles(e)) return;
    e.preventDefault();
    dragDepth.current = 0;
    setIsDragging(false);
    void addFiles(Array.from(e.dataTransfer.files));
  };

  return (
    <div className="mx-auto w-full max-w-3xl px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] sm:px-4">
      {notice && (
        <p role="alert" className="anim-pop mb-2 rounded-xl border border-danger/30 bg-danger-soft px-3.5 py-2 text-[13px] text-fg">
          {notice}
        </p>
      )}

      <div
        onDragEnter={onDragEnter}
        onDragOver={(e) => hasFiles(e) && e.preventDefault()}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
        className={cn(
          'rounded-3xl border bg-raised shadow-float transition-colors',
          isDragging ? 'border-accent bg-accent-soft' : 'border-line focus-within:border-line-strong'
        )}
      >
        {(attachments.length > 0 || isReading) && (
          <div className="flex flex-wrap items-center gap-2 px-3 pt-3">
            {attachments.map((att) => (
              <AttachmentChip
                key={att.id}
                attachment={att}
                onRemove={() => setAttachments((prev) => prev.filter((a) => a.id !== att.id))}
              />
            ))}
            {isReading && (
              <span className="flex items-center gap-2 rounded-xl px-2.5 py-2 text-xs text-muted">
                <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden />
                Fayl oʻqilmoqda...
              </span>
            )}
          </div>
        )}

        <div className="flex items-end gap-1.5 p-2">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept={FILE_ACCEPT}
            className="hidden"
            tabIndex={-1}
            aria-hidden="true"
            onChange={(e) => {
              const files = Array.from(e.target.files ?? []);
              e.target.value = '';
              void addFiles(files);
            }}
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="flex h-10 w-10 shrink-0 cursor-pointer items-center justify-center rounded-full text-muted transition hover:bg-hover hover:text-fg"
            aria-label="Rasm yoki fayl biriktirish"
            title="Rasm, PDF yoki matn/kod fayli biriktirish"
          >
            <Paperclip className="h-5 w-5" aria-hidden />
          </button>

          <textarea
            ref={textareaRef}
            rows={1}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={onKeyDown}
            onPaste={onPaste}
            enterKeyHint="send"
            disabled={!!disabledReason}
            placeholder={
              disabledReason ?? (attachments.length > 0 ? 'Fayl haqida savol yozing...' : 'Core AI dan soʻrang...')
            }
            aria-label="Xabar matni"
            className="max-h-[200px] min-h-10 flex-1 resize-none bg-transparent px-1 py-2 text-[15.5px] leading-6 text-fg outline-none placeholder:text-subtle disabled:cursor-not-allowed"
          />

          {isGenerating ? (
            <button
              type="button"
              onClick={onStop}
              className="flex h-10 w-10 shrink-0 cursor-pointer items-center justify-center rounded-full bg-fg text-canvas transition hover:opacity-85"
              aria-label="Javobni toʻxtatish"
              title="Javobni toʻxtatish"
            >
              <Square className="h-3.5 w-3.5 fill-current" aria-hidden />
            </button>
          ) : (
            <button
              type="button"
              onClick={submit}
              disabled={!canSend}
              className="flex h-10 w-10 shrink-0 cursor-pointer items-center justify-center rounded-full bg-accent text-accent-fg transition hover:bg-accent-strong disabled:cursor-not-allowed disabled:opacity-30 disabled:hover:bg-accent"
              aria-label="Yuborish"
              title="Yuborish (Enter)"
            >
              <ArrowUp className="h-5 w-5 stroke-[2.5]" aria-hidden />
            </button>
          )}
        </div>
      </div>

      <p className="mt-2 hidden text-center text-[11px] text-subtle sm:block">
        Core AI xato qilishi mumkin — muhim maʼlumotlarni tekshiring. Enter — yuborish, Shift+Enter — yangi qator.
      </p>
    </div>
  );
}
