'use client';

import { Check, Laptop, Moon, Sun, Trash2, type LucideIcon } from 'lucide-react';
import type { ThemePreference } from '@/lib/theme';
import { cn } from '@/lib/utils';
import { Dialog } from './Dialog';

interface SettingsModalProps {
  open: boolean;
  onClose: () => void;
  preference: ThemePreference;
  onChangeTheme: (pref: ThemePreference) => void;
  onDeleteAll: () => void;
  hasConversations: boolean;
}

const OPTIONS: Array<{ value: ThemePreference; label: string; hint: string; icon: LucideIcon }> = [
  { value: 'system', label: 'Qurilma', hint: 'Tizim sozlamasiga mos', icon: Laptop },
  { value: 'light', label: 'Yorugʻ', hint: 'Kunduzgi koʻrinish', icon: Sun },
  { value: 'dark', label: 'Qorongʻi', hint: 'Kechki koʻrinish', icon: Moon },
];

export function SettingsModal({ open, onClose, preference, onChangeTheme, onDeleteAll, hasConversations }: SettingsModalProps) {
  return (
    <Dialog open={open} onClose={onClose} title="Sozlamalar" description="Koʻrinish va maʼlumotlarni boshqarish.">
      <fieldset className="mt-5">
        <legend className="mb-2 text-sm font-medium">Mavzu</legend>
        <div className="grid grid-cols-3 gap-2">
          {OPTIONS.map(({ value, label, hint, icon: Icon }) => {
            const selected = preference === value;
            return (
              <label
                key={value}
                className={cn(
                  'relative flex cursor-pointer flex-col items-center gap-1.5 rounded-2xl border px-2 py-3.5 text-center transition has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-accent',
                  selected ? 'border-accent bg-accent-soft' : 'border-line hover:bg-hover'
                )}
              >
                <input
                  type="radio"
                  name="theme"
                  value={value}
                  checked={selected}
                  onChange={() => onChangeTheme(value)}
                  className="sr-only"
                />
                <Icon className={cn('h-5 w-5', selected ? 'text-accent-strong' : 'text-muted')} aria-hidden />
                <span className="text-[13px] font-medium">{label}</span>
                <span className="text-[11px] leading-tight text-subtle">{hint}</span>
                {selected && (
                  <span className="absolute right-1.5 top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-accent text-accent-fg">
                    <Check className="h-3 w-3 stroke-[3]" aria-hidden />
                  </span>
                )}
              </label>
            );
          })}
        </div>
      </fieldset>

      <div className="mt-6 border-t border-line pt-5">
        <p className="text-sm font-medium">Maʼlumotlar</p>
        <p className="mt-1 text-[13px] leading-relaxed text-muted">
          Suhbatlar faqat shu brauzerda saqlanadi. Ularni oʻchirsangiz, qayta tiklab boʻlmaydi.
        </p>
        <button
          type="button"
          disabled={!hasConversations}
          onClick={onDeleteAll}
          className="mt-3 flex cursor-pointer items-center gap-2 rounded-xl border border-danger/40 px-3.5 py-2 text-sm font-medium text-danger transition hover:bg-danger-soft disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-transparent"
        >
          <Trash2 className="h-4 w-4" aria-hidden />
          Barcha suhbatlarni oʻchirish
        </button>
      </div>

      <div className="mt-6 flex justify-end">
        <button
          type="button"
          data-autofocus
          onClick={onClose}
          className="cursor-pointer rounded-xl bg-accent px-5 py-2 text-sm font-semibold text-accent-fg transition hover:bg-accent-strong"
        >
          Tayyor
        </button>
      </div>
    </Dialog>
  );
}
