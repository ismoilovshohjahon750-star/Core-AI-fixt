import { ChevronRight, Code2, Languages, PenLine, Sigma, type LucideIcon } from 'lucide-react';
import { LogoBadge } from './LogoBadge';

interface Starter {
  icon: LucideIcon;
  title: string;
  hint: string;
  prompt: string;
}

const STARTERS: Starter[] = [
  {
    icon: Code2,
    title: 'Kodni tushunish va tuzatish',
    hint: 'Xatoni toping, kodni tushuntiring yoki yangisini yozdiring',
    prompt: 'Quyidagi kodni tekshirib, xatolarini toping va tuzatilgan variantini tushuntirib bering:\n\n',
  },
  {
    icon: Languages,
    title: 'Tabiiy tarjima',
    hint: 'Soʻzma-soʻz emas, mazmuniga mos tarjima',
    prompt: 'Quyidagi matnni oʻzbek tiliga tabiiy va ravon tarjima qiling:\n\n',
  },
  {
    icon: PenLine,
    title: 'Reja, insho yoki xat yozish',
    hint: 'Mavzu va uslubni aytsangiz kifoya',
    prompt: 'Quyidagi mavzuda batafsil reja tuzib, insho yozib bering:\n\n',
  },
  {
    icon: Sigma,
    title: 'Masalani bosqichma-bosqich yechish',
    hint: 'Matematika, foiz, ehtimollik va hisob-kitoblar',
    prompt: 'Quyidagi masalani bosqichma-bosqich yechib, har bir qadamni izohlang:\n\n',
  },
];

export function Welcome({ onPick }: { onPick: (prompt: string) => void }) {
  return (
    <div className="mx-auto flex min-h-full w-full max-w-xl flex-col justify-center py-10">
      <LogoBadge size="lg" />
      <h1 className="mt-6 text-balance text-[28px] font-semibold leading-tight tracking-tight sm:text-[34px]">
        Salom! Bugun nima ustida ishlaymiz?
      </h1>
      <p className="mt-2 max-w-md text-[15px] leading-relaxed text-muted">
        Savol bering, rasm yoki hujjat yuboring. Core AI oʻzbek tilida aniq va tushunarli javob beradi.
      </p>

      <ul className="mt-8 divide-y divide-line border-y border-line">
        {STARTERS.map(({ icon: Icon, title, hint, prompt }) => (
          <li key={title}>
            <button
              type="button"
              onClick={() => onPick(prompt)}
              className="group flex w-full cursor-pointer items-center gap-4 py-3.5 text-left"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent-soft text-accent-strong">
                <Icon className="h-5 w-5" aria-hidden />
              </span>
              <span className="min-w-0 flex-1">
                <span className="block text-[15px] font-medium">{title}</span>
                <span className="block text-[13px] text-muted">{hint}</span>
              </span>
              <ChevronRight
                className="h-4 w-4 shrink-0 text-subtle transition-transform group-hover:translate-x-0.5 group-hover:text-fg"
                aria-hidden
              />
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
