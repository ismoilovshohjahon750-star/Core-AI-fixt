'use client';

import { Dialog } from './Dialog';

export interface ConfirmRequest {
  title: string;
  description: string;
  confirmLabel: string;
  onConfirm: () => void;
}

export function ConfirmDialog({ request, onClose }: { request: ConfirmRequest | null; onClose: () => void }) {
  return (
    <Dialog open={!!request} onClose={onClose} title={request?.title ?? ''} description={request?.description}>
      <div className="mt-5 flex items-center justify-end gap-2">
        <button
          type="button"
          data-autofocus
          onClick={onClose}
          className="cursor-pointer rounded-xl px-4 py-2 text-sm font-medium text-muted transition hover:bg-hover hover:text-fg"
        >
          Bekor qilish
        </button>
        <button
          type="button"
          onClick={() => {
            request?.onConfirm();
            onClose();
          }}
          className="cursor-pointer rounded-xl bg-danger px-4 py-2 text-sm font-semibold text-canvas transition hover:opacity-90"
        >
          {request?.confirmLabel}
        </button>
      </div>
    </Dialog>
  );
}
