'use client';

import { useMemo, useRef, useState } from 'react';
import { Check, Image as ImageIcon, MessageSquare, PanelLeftClose, Pencil, Plus, Search, Settings, Trash2, X } from 'lucide-react';
import type { Conversation } from '@/lib/types';
import {
  CATEGORY_LABELS,
  CATEGORY_ORDER,
  filterConversations,
  getAllMediaFromConversations,
  groupConversations,
} from '@/lib/chat-utils';
import { USER_NAME, getInitials } from '@/lib/config';
import { cn } from '@/lib/utils';
import { LogoBadge } from './LogoBadge';
import { MediaSection } from './MediaSection';

interface SidebarProps {
  conversations: Conversation[];
  activeId: string | null;
  mobileOpen: boolean;
  desktopOpen: boolean;
  onClose: () => void;
  onSelect: (id: string) => void;
  onNewChat: () => void;
  onDelete: (id: string) => void;
  onRename: (id: string, title: string) => void;
  onOpenSettings: () => void;
}

function RenameField({ initial, onDone }: { initial: string; onDone: (value: string | null) => void }) {
  const [value, setValue] = useState(initial);
  const finished = useRef(false);

  const finish = (result: string | null) => {
    if (finished.current) return;
    finished.current = true;
    onDone(result);
  };

  return (
    <div className="flex items-center gap-1 px-2 py-1.5">
      <input
        autoFocus
        value={value}
        maxLength={80}
        onChange={(e) => setValue(e.target.value)}
        onFocus={(e) => e.currentTarget.select()}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && !e.nativeEvent.isComposing) finish(value.trim() || null);
          if (e.key === 'Escape') finish(null);
        }}
        onBlur={() => finish(value.trim() || null)}
        aria-label="Suhbat nomi"
        className="min-w-0 flex-1 rounded-lg border border-accent bg-canvas px-2.5 py-1.5 text-sm outline-none"
      />
      <button
        type="button"
        onMouseDown={(e) => e.preventDefault()}
        onClick={() => finish(value.trim() || null)}
        className="cursor-pointer rounded-md p-1.5 text-ok hover:bg-hover"
        aria-label="Saqlash"
      >
        <Check className="h-4 w-4" aria-hidden />
      </button>
      <button
        type="button"
        onMouseDown={(e) => e.preventDefault()}
        onClick={() => finish(null)}
        className="cursor-pointer rounded-md p-1.5 text-subtle hover:bg-hover hover:text-fg"
        aria-label="Bekor qilish"
      >
        <X className="h-4 w-4" aria-hidden />
      </button>
    </div>
  );
}

export function Sidebar({
  conversations,
  activeId,
  mobileOpen,
  desktopOpen,
  onClose,
  onSelect,
  onNewChat,
  onDelete,
  onRename,
  onOpenSettings,
}: SidebarProps) {
  const [tab, setTab] = useState<'chats' | 'media'>('chats');
  const [query, setQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);

  const filtered = useMemo(() => filterConversations(conversations, query), [conversations, query]);
  const grouped = useMemo(() => groupConversations(filtered), [filtered]);
  const mediaCount = useMemo(() => getAllMediaFromConversations(conversations).length, [conversations]);

  const tabs = [
    { id: 'chats' as const, label: 'Suhbatlar', icon: MessageSquare },
    { id: 'media' as const, label: mediaCount > 0 ? `Fayllar ${mediaCount}` : 'Fayllar', icon: ImageIcon },
  ];

  return (
    <>
      {mobileOpen && (
        <div onClick={onClose} className="anim-fade fixed inset-0 z-30 bg-black/55 lg:hidden" aria-hidden="true" />
      )}

      <aside
        aria-label="Yon panel"
        className={cn(
          'fixed inset-y-0 left-0 z-40 w-[18.5rem] max-w-[86vw] overflow-hidden border-r border-line bg-panel transition-[transform,width,visibility] duration-200 ease-out lg:static lg:max-w-none',
          mobileOpen ? 'translate-x-0 visible' : '-translate-x-full invisible',
          desktopOpen ? 'lg:visible lg:w-72 lg:translate-x-0' : 'lg:invisible lg:w-0 lg:-translate-x-full lg:border-r-0'
        )}
      >
        <div className="flex h-full w-[18.5rem] max-w-[86vw] flex-col pt-[env(safe-area-inset-top)] lg:w-72 lg:max-w-none">
          <div className="flex items-center justify-between px-4 py-3.5">
            <div className="flex items-center gap-2.5">
              <LogoBadge size="md" />
              <span className="text-[17px] font-semibold tracking-tight">Core AI</span>
            </div>
            <button
              type="button"
              onClick={onClose}
              className="cursor-pointer rounded-lg p-2 text-subtle transition hover:bg-hover hover:text-fg"
              aria-label="Panelni yopish"
              title="Panelni yopish"
            >
              <PanelLeftClose className="h-[18px] w-[18px]" aria-hidden />
            </button>
          </div>

          <div className="px-3">
            <button
              type="button"
              onClick={onNewChat}
              className="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-accent py-2.5 text-sm font-semibold text-accent-fg transition hover:bg-accent-strong"
            >
              <Plus className="h-4 w-4 stroke-[2.5]" aria-hidden />
              Yangi suhbat
            </button>
          </div>

          <div className="mt-3 flex gap-1 px-3" role="tablist" aria-label="Boʻlimlar">
            {tabs.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                type="button"
                role="tab"
                aria-selected={tab === id}
                onClick={() => setTab(id)}
                className={cn(
                  'flex flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-lg py-1.5 text-[13px] font-medium transition',
                  tab === id ? 'bg-raised text-fg shadow-sm' : 'text-muted hover:text-fg'
                )}
              >
                <Icon className="h-3.5 w-3.5" aria-hidden />
                {label}
              </button>
            ))}
          </div>

          <div className="px-3 py-2.5">
            <label className="flex items-center gap-2 rounded-xl border border-line bg-canvas px-3 py-2 text-sm transition focus-within:border-accent">
              <Search className="h-4 w-4 shrink-0 text-subtle" aria-hidden />
              <input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={tab === 'media' ? 'Fayl qidirish...' : 'Suhbatlardan qidirish...'}
                aria-label="Qidirish"
                className="w-full min-w-0 bg-transparent text-[13px] outline-none placeholder:text-subtle [&::-webkit-search-cancel-button]:hidden"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => setQuery('')}
                  className="cursor-pointer rounded p-0.5 text-subtle hover:text-fg"
                  aria-label="Qidiruvni tozalash"
                >
                  <X className="h-3.5 w-3.5" aria-hidden />
                </button>
              )}
            </label>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto" role="tabpanel">
            {tab === 'media' ? (
              <MediaSection
                conversations={conversations}
                searchQuery={query}
                onSelectConversation={(id) => {
                  onSelect(id);
                }}
              />
            ) : filtered.length === 0 ? (
              <div className="px-6 py-14 text-center">
                <p className="text-sm font-medium">{query ? 'Hech narsa topilmadi' : 'Suhbatlar hali yoʻq'}</p>
                <p className="mt-1 text-xs leading-relaxed text-muted">
                  {query ? 'Boshqa soʻz bilan qidirib koʻring.' : 'Birinchi savolingizni yozing — suhbat shu yerda saqlanadi.'}
                </p>
              </div>
            ) : (
              <nav aria-label="Suhbatlar tarixi" className="space-y-4 px-2 pb-3">
                {CATEGORY_ORDER.map((cat) => {
                  const items = grouped[cat];
                  if (items.length === 0) return null;
                  return (
                    <section key={cat}>
                      <h3 className="px-3 pb-1 text-xs font-medium text-subtle">{CATEGORY_LABELS[cat]}</h3>
                      <ul className="space-y-0.5">
                        {items.map((conv) => {
                          const isActive = conv.id === activeId;
                          if (editingId === conv.id) {
                            return (
                              <li key={conv.id}>
                                <RenameField
                                  initial={conv.title}
                                  onDone={(value) => {
                                    if (value && value !== conv.title) onRename(conv.id, value);
                                    setEditingId(null);
                                  }}
                                />
                              </li>
                            );
                          }
                          return (
                            <li key={conv.id} className="group relative">
                              <button
                                type="button"
                                onClick={() => onSelect(conv.id)}
                                aria-current={isActive ? 'page' : undefined}
                                className={cn(
                                  'w-full cursor-pointer rounded-xl px-3 py-2 pr-16 text-left transition',
                                  isActive ? 'bg-accent-soft' : 'hover:bg-hover'
                                )}
                              >
                                <span className={cn('block truncate text-sm', isActive ? 'font-semibold' : 'font-medium')}>
                                  {conv.title}
                                </span>
                                <span className="mt-0.5 block truncate text-xs text-subtle">{conv.snippet}</span>
                              </button>
                              <div className="absolute right-1.5 top-1/2 flex -translate-y-1/2 items-center lg:opacity-0 lg:group-focus-within:opacity-100 lg:group-hover:opacity-100">
                                <button
                                  type="button"
                                  onClick={() => setEditingId(conv.id)}
                                  className="cursor-pointer rounded-md p-1.5 text-subtle transition hover:bg-line hover:text-fg"
                                  aria-label={`Nomini oʻzgartirish: ${conv.title}`}
                                  title="Nomini oʻzgartirish"
                                >
                                  <Pencil className="h-3.5 w-3.5" aria-hidden />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => onDelete(conv.id)}
                                  className="cursor-pointer rounded-md p-1.5 text-subtle transition hover:bg-danger-soft hover:text-danger"
                                  aria-label={`Oʻchirish: ${conv.title}`}
                                  title="Oʻchirish"
                                >
                                  <Trash2 className="h-3.5 w-3.5" aria-hidden />
                                </button>
                              </div>
                            </li>
                          );
                        })}
                      </ul>
                    </section>
                  );
                })}
              </nav>
            )}
          </div>

          <div className="border-t border-line p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
            <div className="flex items-center gap-3 rounded-xl p-1.5">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent-soft text-xs font-semibold text-accent-strong">
                {getInitials(USER_NAME)}
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{USER_NAME}</p>
                <p className="truncate text-xs text-subtle">Suhbatlar shu qurilmada saqlanadi</p>
              </div>
              <button
                type="button"
                onClick={onOpenSettings}
                className="cursor-pointer rounded-lg p-2 text-subtle transition hover:bg-hover hover:text-fg"
                aria-label="Sozlamalar"
                title="Sozlamalar"
              >
                <Settings className="h-[18px] w-[18px]" aria-hidden />
              </button>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
