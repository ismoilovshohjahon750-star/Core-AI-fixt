'use client';

import { useMemo, useState } from 'react';
import { Download, FileCode, FileText, Image as ImageIcon } from 'lucide-react';
import type { Conversation, MediaItem } from '@/lib/types';
import { formatFileSize, getAllMediaFromConversations, isCodeFileName, isImageAttachment } from '@/lib/chat-utils';
import { downloadAttachment } from '@/lib/file-utils';
import { cn } from '@/lib/utils';
import { ImageLightbox } from './ImageLightbox';

type Filter = 'all' | 'images' | 'files';

interface MediaSectionProps {
  conversations: Conversation[];
  searchQuery: string;
  onSelectConversation: (id: string) => void;
}

export function MediaSection({ conversations, searchQuery, onSelectConversation }: MediaSectionProps) {
  const [filter, setFilter] = useState<Filter>('all');
  const [preview, setPreview] = useState<MediaItem | null>(null);

  const all = useMemo(() => getAllMediaFromConversations(conversations), [conversations]);

  const visible = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return all.filter((item) => {
      if (q && !item.attachment.name.toLowerCase().includes(q) && !item.conversationTitle.toLowerCase().includes(q)) {
        return false;
      }
      const isImage = isImageAttachment(item.attachment);
      return filter === 'all' || (filter === 'images' ? isImage : !isImage);
    });
  }, [all, filter, searchQuery]);

  if (all.length === 0) {
    return (
      <div className="flex flex-col items-center px-6 py-14 text-center">
        <span className="mb-3 flex h-11 w-11 items-center justify-center rounded-2xl bg-accent-soft text-accent-strong">
          <ImageIcon className="h-5 w-5" aria-hidden />
        </span>
        <p className="text-sm font-medium">Hozircha fayllar yoʻq</p>
        <p className="mt-1 max-w-[14rem] text-xs leading-relaxed text-muted">
          Suhbatda yuborgan rasm va hujjatlaringiz shu yerda toʻplanadi.
        </p>
      </div>
    );
  }

  const chips: Array<[Filter, string]> = [
    ['all', `Barchasi ${all.length}`],
    ['images', 'Rasmlar'],
    ['files', 'Hujjatlar'],
  ];

  return (
    <div className="flex h-full flex-col">
      <div className="flex gap-1.5 px-3 pb-2" role="group" aria-label="Fayl turi">
        {chips.map(([value, label]) => (
          <button
            key={value}
            type="button"
            onClick={() => setFilter(value)}
            aria-pressed={filter === value}
            className={cn(
              'cursor-pointer rounded-full px-3 py-1 text-xs font-medium transition',
              filter === value ? 'bg-fg text-canvas' : 'text-muted hover:bg-hover hover:text-fg'
            )}
          >
            {label}
          </button>
        ))}
      </div>

      <ul className="min-h-0 flex-1 space-y-1 overflow-y-auto px-2 pb-2">
        {visible.length === 0 && <li className="px-3 py-8 text-center text-xs text-muted">Hech narsa topilmadi</li>}
        {visible.map((item) => {
          const att = item.attachment;
          const isImg = isImageAttachment(att) && !!att.dataUrl;
          const Icon = isCodeFileName(att.name) ? FileCode : FileText;
          return (
            <li key={item.id} className="group relative">
              <button
                type="button"
                onClick={() => (isImg ? setPreview(item) : onSelectConversation(item.conversationId))}
                className="flex w-full cursor-pointer items-center gap-3 rounded-xl p-2 text-left transition hover:bg-hover"
              >
                {isImg ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={att.dataUrl} alt="" className="h-11 w-11 shrink-0 rounded-lg object-cover" />
                ) : (
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-accent-soft text-accent-strong">
                    <Icon className="h-5 w-5" aria-hidden />
                  </span>
                )}
                <span className="min-w-0 flex-1 pr-7">
                  <span className="block truncate text-[13px] font-medium">{att.name}</span>
                  <span className="block truncate text-xs text-subtle">
                    {formatFileSize(att.size)} · {item.conversationTitle}
                  </span>
                </span>
              </button>
              {(att.dataUrl || att.textContent) && (
                <button
                  type="button"
                  onClick={() => downloadAttachment(att)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 cursor-pointer rounded-md p-1.5 text-subtle transition hover:bg-line hover:text-fg lg:opacity-0 lg:group-focus-within:opacity-100 lg:group-hover:opacity-100"
                  aria-label={`Yuklab olish: ${att.name}`}
                >
                  <Download className="h-4 w-4" aria-hidden />
                </button>
              )}
            </li>
          );
        })}
      </ul>

      <ImageLightbox
        attachment={preview?.attachment ?? null}
        subtitle={preview?.conversationTitle}
        onClose={() => setPreview(null)}
        extraAction={
          preview
            ? {
                label: 'Suhbatga oʻtish',
                onClick: () => {
                  onSelectConversation(preview.conversationId);
                  setPreview(null);
                },
              }
            : undefined
        }
      />
    </div>
  );
}
