'use client';

import { Download, X } from 'lucide-react';
import type { ChatAttachment } from '@/lib/types';
import { downloadAttachment } from '@/lib/file-utils';
import { formatFileSize } from '@/lib/chat-utils';
import { Dialog } from './Dialog';

interface ImageLightboxProps {
  attachment: ChatAttachment | null;
  subtitle?: string;
  onClose: () => void;
  extraAction?: { label: string; onClick: () => void };
}

export function ImageLightbox({ attachment, subtitle, onClose, extraAction }: ImageLightboxProps) {
  return (
    <Dialog open={!!attachment} onClose={onClose} title={attachment?.name ?? 'Rasm'} className="max-w-4xl p-3 sm:p-4">
      {attachment && (
        <>
          <p className="mt-0.5 text-xs text-muted">
            {formatFileSize(attachment.size)}
            {subtitle ? ` · ${subtitle}` : ''}
          </p>
          {attachment.dataUrl && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={attachment.dataUrl}
              alt={attachment.name}
              className="mx-auto mt-3 max-h-[70dvh] w-auto max-w-full rounded-xl object-contain"
            />
          )}
          <div className="mt-3 flex items-center justify-end gap-2">
            {extraAction && (
              <button
                type="button"
                onClick={extraAction.onClick}
                className="cursor-pointer rounded-xl px-3 py-2 text-sm font-medium text-muted transition hover:bg-hover hover:text-fg"
              >
                {extraAction.label}
              </button>
            )}
            <button
              type="button"
              onClick={() => downloadAttachment(attachment)}
              className="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-muted transition hover:bg-hover hover:text-fg"
            >
              <Download className="h-4 w-4" aria-hidden />
              Yuklab olish
            </button>
            <button
              type="button"
              data-autofocus
              onClick={onClose}
              className="flex cursor-pointer items-center gap-2 rounded-xl bg-accent px-3.5 py-2 text-sm font-semibold text-accent-fg transition hover:bg-accent-strong"
            >
              <X className="h-4 w-4" aria-hidden />
              Yopish
            </button>
          </div>
        </>
      )}
    </Dialog>
  );
}
