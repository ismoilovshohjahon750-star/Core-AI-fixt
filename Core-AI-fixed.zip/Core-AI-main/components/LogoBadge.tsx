import { cn } from '@/lib/utils';

interface LogoBadgeProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const BOX = { sm: 'h-6 w-6 rounded-lg', md: 'h-8 w-8 rounded-[10px]', lg: 'h-14 w-14 rounded-2xl' } as const;
const ICON = { sm: 14, md: 18, lg: 32 } as const;

/** Core AI belgisi: ochiq halqa (orbita) va markazdagi yadro. */
export function LogoBadge({ size = 'md', className }: LogoBadgeProps) {
  return (
    <span
      role="img"
      aria-label="Core AI"
      className={cn('inline-flex shrink-0 select-none items-center justify-center bg-accent text-accent-fg', BOX[size], className)}
    >
      <svg width={ICON[size]} height={ICON[size]} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path
          d="M18.2 7.2A8 8 0 1 0 18.2 16.8"
          stroke="currentColor"
          strokeWidth="2.4"
          strokeLinecap="round"
        />
        <circle cx="12.5" cy="12" r="2.9" fill="currentColor" />
      </svg>
    </span>
  );
}
